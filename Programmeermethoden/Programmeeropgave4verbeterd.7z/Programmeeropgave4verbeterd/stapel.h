// file stapel.h
