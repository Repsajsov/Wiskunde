#include <cstdlib>
#include <ctime>
#include <iostream>
#include <unistd.h>

class OthelloBord {
    public:
    private:
}









int main() {

}